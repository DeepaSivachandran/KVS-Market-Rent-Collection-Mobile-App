<?php
// include db connect class
require_once __DIR__ . '/db_config.php';
  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");


   $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD,DB_DATABASE) or die(mysqli_error($con));

    mysqli_set_charset($con,"utf8");
  
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/

      $tenantcode = urldecode($_POST['tenantcode']);

      $tenantname  = urldecode($_POST['tenantname']);

      $totalamount  = urldecode($_POST['totalamount']);
      $statuscode  = urldecode($_POST['statuscode']);
      $receiptno   = urldecode($_POST['receiptno']);
      $receiptcode  = urldecode($_POST['receiptcode']);
      $shopcode = urldecode($_POST['shopcode']);
      $shopname  = urldecode($_POST['shopname']);
      $rentcycle = urldecode($_POST['rentcycle']);
      $shopstatus  = urldecode($_POST['shopstatus']);
      $rent = urldecode($_POST['rent']);
      $collectiondate = urldecode($_POST['collectiondate']);;

      $deviceid="121";

      // $tenantcode = "";
      // $tenantname ="";

      // $totalamount = "0";
      // $statuscode = "10";
      // $receiptno = "";
      // $receiptcode = "";
      // $shopcode ="";
      // $shopname  ="";
      // $rentcycle = "";
      // $shopstatus = "";
      // $rent ="";
      // $collectiondate = "2023-01-27 00:00:00";

    $response["logindetails"] = array();
    $response["companydetails"] = array();
    
	
	if($deviceid !=""){
     $collectioncode = 0;

     //statuscode 10 is paid 
     $sql_collection ="INSERT INTO tblcollections(collectioncode, totalamount, statuscode, createddate, receiptno, receiptcode)
                        (SELECT COALESCE(MAX(a.collectioncode),0)+1, '$totalamount', '10', now(), '$receiptno', '$receiptcode' FROM tblcollections as a) ";

     $result = mysqli_stmt_init($con);

     $sql_collection_result = mysqli_query($con,$sql_collection);
   

     //echo $worker_list; die;
     
      if (!empty($sql_collection_result)) {
        $last_inserted = mysqli_insert_id($con);
        $sql_collection_select ="SELECT collectioncode FROM tblcollections as a  WHERE a.autonum = '$last_inserted';";
  
          $result = mysqli_stmt_init($con);
          $sql_collection_select_result = mysqli_query($con,$sql_collection_select);

      if (mysqli_num_rows($sql_collection_select_result) > 0) {
    
          while($row = mysqli_fetch_array($sql_collection_select_result)) 
          {
            
             $collectioncode = $row["collectioncode"];
            // echo   $collectioncode ;
           }

           if($collectioncode != 0){

            //OLD
            // $sql_collection_shop = "INSERT INTO tblcollection_shop (collectioncode,shopcode, name, rentcycle,shopstatus,rent,collectiondate) 
            //                           VALUES ( '$collectioncode', '$shopcode', '$shopname', '$rentcycle', '$shopstatus', '$totalamount','$collectiondate');";
             
             //NEW 
             $sql_collection_shop = " INSERT INTO tblcollection_shop (collectioncode,shopcode, name, rentcycle,shopstatus,rent,collectiondate)
                                        SELECT '$collectioncode' as collectioncode, '$shopcode' as shopcode, '$shopname' as name, '$rentcycle' as rentcycle, '$shopstatus' as shopstatus, '$totalamount' as rent, DATE_FORMAT(ADDTIME(STR_TO_DATE('$collectiondate','%Y-%m-%d'), (SELECT timediff FROM tblsettings)), '%Y-%m-%d') as collectiondate
                                        ";
            // echo $sql_collection_shop ; die ;
                  $result = mysqli_stmt_init($con);
                  $sql_collection_shop_result  = mysqli_query($con,$sql_collection_shop);
                
                  if (!empty($sql_collection_shop_result)) {
                    // check for empty result

                    
                    $last_inserted = mysqli_insert_id($con);
                    $sql_collection_shop_select = "SELECT collectioncode FROM tblcollection_shop as a  WHERE a.autonum = '$last_inserted'";

                    $sql_collection_shop_select_result  = mysqli_query($con,$sql_collection_shop_select);

                    if (mysqli_num_rows($sql_collection_shop_select_result) > 0) {
                  
                        while($row = mysqli_fetch_array($sql_collection_shop_select_result)) 
                        {
                          
                          $collectioncode = $row["collectioncode"];
                         // echo   $collectioncode ;
                        }

                        if($collectioncode != 0){

                          $sql_collection_tenant = "INSERT INTO tbblcollection_tenant (tenantcode,tenantname,collectioncode) 
                                                      VALUES ( '$tenantcode', '$tenantname', '$collectioncode');";
                                                    

                            $result = mysqli_stmt_init($con);
                            $sql_collection_tenant_result  = mysqli_query($con,$sql_collection_tenant);
                              if (!empty($sql_collection_tenant_result)) {

                                $last_inserted = mysqli_insert_id($con);
                                $tbblcollection_tenant_select = "SELECT collectioncode FROM tbblcollection_tenant as a  WHERE a.autonum = '$last_inserted'";
            
                                $tbblcollection_tenant_select_result  = mysqli_query($con,$tbblcollection_tenant_select);
                                if (mysqli_num_rows($tbblcollection_tenant_select_result) > 0) {

                                    while($row = mysqli_fetch_array($tbblcollection_tenant_select_result)) 
                                    {
                                      
                                      $collectioncode = $row["collectioncode"];
                                    // echo   $collectioncode ;
                                    }
                                    $response["success"] = 1;
                                    //echo json_encode($response);
                                  }
                                }
                        }
                        }
                    }
           }

           }
           else{
            $response["success"] = 2;
            //echo json_encode($response);
          }
          }else{
            $response["error"] =  mysqli_error($con);
            $response["success"] = 3;
            //echo json_encode($response);
          }

     //echo $sql ; die;
     echo json_encode($response);
		   
	}

mysqli_close($con);
?>