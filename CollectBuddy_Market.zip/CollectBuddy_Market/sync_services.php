<?php
// include db connect class

require_once __DIR__ . '/db_config.php';
//To Write error log
 ///require_once __DIR__ . '/catchexception.php'; 


  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");

  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
  //mysqli_set_charset($con,"utf8");
  
    if(isset($_POST['paracode'])){
		
      $agent_code = urldecode($_POST['paracode']);
	}
	else{
	  $agent_code="";
	}

  $acno         = urldecode($_POST['paraacno']);
  $receiptno    = urldecode($_POST['parareceiptno']);
  $actype       = urldecode($_POST['paraactype']); 
  $modepay      = urldecode($_POST['paramodepay']);
  $cancel       = urldecode($_POST['paracancel']);
  $tr_time      = urldecode($_POST['paratr_time']);
  $chequedt     = urldecode($_POST['parachequedt']); 
  $chequeno     = urldecode($_POST['parachequeno']); 
  $collectdt    = urldecode($_POST['paracollectdt']);
  $collectamt   = urldecode($_POST['paracollectamt']); 
  $remark       = urldecode($_POST['pararemark']);
  $receiptcode  = urldecode($_POST['parareceiptcode']);
  $customer_type  = urldecode($_POST['paracustomer_type']);

  $customer_name  = urldecode($_POST['paracustomer_name']);
  $phone_no  = urldecode($_POST['paraphone_no']);
  $city = urldecode($_POST['paracity']);
  $customer_no = urldecode($_POST['paracustomer_no']);

  

  if($acno ==""){
    $acno ="null";
  }

 // $acno         = "25352";
 /* $receiptno    = "456";
  $actype       = "D200"; 
  $modepay      = "CASH"; 
  $cancel       = "N";
  $tr_time      = "05:30"; 
  $chequedt     = "09-08-2022"; 
  $chequeno     = "25235253"; 
  $collectdt    = "09-08-2022";
  $collectamt   = "4300"; 
  $remark       = "pkm";
  $receiptcode  = "80456";
  $customer_type ="1";*/
    if($agent_code !=""){
      
      $params = array();	 
      $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );

     //  $sql_check = "SELECT coalesce(MAX(transactid)+1,0) as transactid FROM transact";

       //$sql = "INSERT INTO transact(transactid,acno,receiptno,actype,ag_code,modepay,cancel,tr_time,chequedt,chequeno,collectdt,collectamt,remark,receipt_code,sync_date,sync_flag,customer_type) values((SELECT coalesce(MAX(transactid)+1,0) FROM transact) , $acno, $receiptno,'$actype','$agent_code','$modepay','$cancel','$tr_time','$chequedt','$chequeno','$collectdt',$collectamt,'$remark','$receiptcode',GETDATE(),'1','$customer_type');";
      
         $sql = "INSERT INTO transact(transactid,acno,receiptno,actype,ag_code,modepay,cancel,tr_time,collectdt,collectamt,Description,receipt_code,sync_date,sync_flag,customer_type,Customer_name,Phone_no,City,Customer_no) values((SELECT coalesce(MAX(transactid)+1,0) FROM transact) , '$acno', '$receiptcode','$actype','$agent_code','$modepay','$cancel','$tr_time','$collectdt',$collectamt,'$remark',$receiptno,GETDATE(),'1','$customer_type','$customer_name','$phone_no','$city','$customer_no');";

       //echo $sql; die;
       
       $result = sqlsrv_query($con,$sql,$params,$options);

       if($result){

        $response["success"] = 1;
        $response["error"]   = "";
       //echo 'success';

        echo  json_encode($response);
       }else{
  
        $err = sqlsrv_errors(); 
        $response["success"] = 0;
        $response["error"] = $err;

        echo  json_encode($response);
       }

     }


sqlsrv_close($con);
?>
