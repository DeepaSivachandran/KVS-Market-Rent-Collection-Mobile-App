<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="container-fluid" style="margin-top:80px !important; margin-left:8%;">
        <div class="container">
            <div class="row mb-2">
                <div class="col-md-9">
                    <h1 >Datatable</h1>
                </div>
                
            </div>
            

            <?php
			// include db connect class
			  require_once __DIR__ . '/db_config.php';
			  //To Write error log
			  ///require_once __DIR__ . '/catchexception.php'; 
			  // connecting to db
			  $response = array();
			  
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");

			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  //mysqli_set_charset($con,"utf8");
  
               
                $sql = "SELECT login_pk,code,agent,deviceid FROM dbo.login";
                $result = sqlsrv_query($con,$sql);
            ?>

            <table id="tblUser">
                <thead>
                    <th>S.No</th>
                    <th>Agent Code</th>
                    <th>Agent Name</th>
					<th>Device Id</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php while($user = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) { ?>
					   
                        <tr>
                            <td><?php echo $user['login_pk'];  ?></td>
                            <td><?php echo $user['code']; ?></td>
                            <td><?php echo $user['agent']; ?></td>
							<td><?php echo $user['deviceid']; ?></td>
                            <td>
                                <a href="update_data_form.php?id=<?php echo $user['id']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"></i></a>
                             
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
     
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#tblUser').DataTable();
        $("#form-body").hide();

    } );
    </script>

</body>
</html>