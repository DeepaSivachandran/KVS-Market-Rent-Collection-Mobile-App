<?php

	$user_name=$_POST['user_name'];
	$pwd = hash('sha256', $_POST['pwd']);
	
	
	require_once __DIR__ . '/db_config.php';
	$conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
	$con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
	 $params = array();	 
	$response=array();
	$report=array();
	$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$sql1="select * from dbo.userdetails where user_name='$user_name'";
	$check = sqlsrv_query($con,$sql1,$params,$options);

	if(sqlsrv_num_rows($check)>0)
	  {
		  $query = "SELECT user_name,pwd,user_id FROM dbo.userdetails WHERE user_name='$user_name' AND pwd='$pwd'";
		  
		  $result = sqlsrv_query($con,$query,$params,$options);
			  
		  if (sqlsrv_num_rows($result)>0) 
		  {  
			  while($row = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC))
			  {
				  session_start();
				  $_SESSION['user_id'] = $row['user_id'];
			  }
			  $data='success';
		  }
		  else
		  {
			   $data='error';
		  }
	  }    
	  else
	  {
		  $data="User Name or Password incorrect";
		  $message="error";
	  }
	  $report["message"] =$data;
	  echo json_encode($report)
?>

