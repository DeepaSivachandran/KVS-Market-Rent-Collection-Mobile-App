<?php

$old_pwd=hash('sha256', $_POST['old_pwd']);
$new_pwd = hash('sha256', $_POST['new_pwd']);
	
			  require_once __DIR__ . '/db_config.php';
			
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
				
			    $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  	 
	               $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
			  
			       $params = array();	 
				   
				    session_start();
					$user_id =  $_SESSION['user_id'];
					
				   $sql="SELECT count(*) as count FROM dbo.userdetails WHERE user_id = $user_id AND pwd='$old_pwd'";
				   $usercount = sqlsrv_query($con,$sql,$params,$options);

				   if(sqlsrv_num_rows($usercount)> 0)
				   {
					while($row = sqlsrv_fetch_array($usercount,SQLSRV_FETCH_ASSOC)) 
					{
						$count = $row['count'];
					}
				   }
			 
				   if ($count == 0) {
					 $data ='Old password is wrong';
				   }
				   else {
					$sql_user = "UPDATE dbo.userdetails SET pwd= '$new_pwd' WHERE user_id = $user_id ";	
					$result = sqlsrv_query($con,$sql_user,$params,$options);
						
					if (!empty($result)) 
					{  
						$data='success';
					}
					else
					{
						 $data='error';
					}
				   }
				
				   $report["message"] =$data;
					 
					echo json_encode($report)
            
    
?>