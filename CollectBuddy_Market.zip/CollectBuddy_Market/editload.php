<?php

    $id = $_POST['id'];
 
			  require_once __DIR__ . '/db_config.php';
			  
			  $response = array();
			  
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
				
			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));

			  $params = array();	 
			  $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
				
                $sql = "SELECT login_pk,code,agent,deviceid,status,passcode FROM dbo.login WHERE login_pk = '$id'";
				 $result = sqlsrv_query($con,$sql,$params,$options);
				 if (!empty($result)) {
          
              if (sqlsrv_num_rows($result) > 0) {
     
                  while($row = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) 
                  {
                 $response['login_pk']= $row["login_pk"];
			     $response['code']=$row["code"];
				 $response['agent']=$row["agent"];
				 $response['deviceid']=$row["deviceid"];
                 $response['status']=$row["status"];
				 $response['passcode']=$row["passcode"];
                  }
				
				  echo json_encode($response);
			  }
			  else{
				  echo json_encode($response);
			  }
			}
			else{
				echo json_encode($response);
			}

?>