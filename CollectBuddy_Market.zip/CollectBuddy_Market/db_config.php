<?php
 
/*
 * All database connection variables*/

//define('DB_USER', "shivasof_pems"); // db user
//define('DB_PASSWORD', "ew.R?10ZpM)G"); // db password (mention your db password here)
//define('DB_DATABASE', "shivasof_pems"); // database name
//define('DB_SERVER', "localhost"); // db server

define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password (mention your db password here)
define('DB_DATABASE', "dbrentcollection"); // database name
define('DB_SERVER', "172.16.1.200"); // db server
?>