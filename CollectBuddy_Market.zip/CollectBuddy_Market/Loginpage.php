<html>
<head>
<style>
*{
	font-family: "Arial, sans-serif";
	
}
.center {
	margin-left:300px;
  justify-content: center;
  align-items: center;

 
}
.login_oueter{
	width:50%;
	 
}
</style>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous" />
<!-- font awesome  -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous" />

</head>
<body style="background-color:#054468">
<div class="container-fluid" >
  <div class="row d-flex justify-content-center align-items-center m-0" style="height: 90vh;">
    <div class="login_oueter bg-light border p-3">
      
      <form  method="post" id="login" autocomplete="off" >

	   <h4 align="center">Login Page</h4>
        <div class="form-row">
         
          <div class="container">
		  <label for="uname">User Name</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              </div>
			  
              <input name="username" type="text"  class="input form-control" id="user_name" placeholder="Enter Username" required="true" aria-label="Username" aria-describedby="basic-addon1" />
            </div>
         
         
		  <label for="psw">Password</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
              </div>
              <input name="password" type="password"  maxlength="6"  class="input form-control" id="pwd" placeholder="Enter password" required="true" aria-label="password" aria-describedby="basic-addon1" />
              <div class="input-group-append">
                <span class="input-group-text" onclick="password_show_hide();">
                  <i class="fas fa-eye" id="show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                </span>
              </div>
            </div>
          </div>
 </div>
       
			<div class="center">
            <button class="btn btn-primary" type="button" onclick="loginvalidate()" name="signin">Login</button>
          </div>
		 
      </form>
    </div>
  </div>
</div>
</body>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
function password_show_hide()
 {
	var x = document.getElementById("pwd");
	var show_eye = document.getElementById("show_eye");
	var hide_eye = document.getElementById("hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}
function loginvalidate(){
toastr.options.timeOut = 1500;
	var user_name=$("#user_name").val();
	var pwd=$("#pwd").val();
		 $.ajax({
            url: 'loginvalidate.php',
            type: 'POST',
			data : {user_name:user_name,pwd:pwd},
            success: function(json)
			{
				$json = JSON.parse(json);
			   if($json['message']=='success')
			   {
				   
					toastr.success("Login successfully");
					top.location.href="sidebar.php";
								 			
			   }
			   else{
				    toastr.error("Username or Password is incorrect");
			      }
            }
			
        });
}
</script>