<?php
// include db connect class
require_once __DIR__ . '/db_config.php';
  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");


   $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD,DB_DATABASE) or die(mysqli_error($con));

    mysqli_set_charset($con,"utf8");
  
    if(isset($_POST['paradeviceid'])){
		
      $deviceid = urldecode($_POST['paradeviceid']);
	   }
	  else{
	   $deviceid="";
	   }
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/
    //  $deviceid="f22d1103dcce2f11";

    $response["logindetails"] = array();
    $response["companydetails"] = array();
    
	
	if($deviceid !=""){
     $sql ="SELECT * FROM tblusermaster WHERE deviceid = '$deviceid';";

     $sql_company = "SELECT * FROM tblcompanymaster WHERE statuscode ='1' LIMIT 1";

     $result = mysqli_stmt_init($con);

     $sql_result = mysqli_query($con,$sql);

     $sql_company_result  = mysqli_query($con,$sql_company);

     //echo $worker_list; die;
     
      if (!empty($sql_result)) {
      // check for empty result
      if (mysqli_num_rows($sql_result) > 0) {
    
          while($row = mysqli_fetch_array($sql_result)) 
          {
                 $user = array();
                 $user["usercode"]           = $row["usercode"];
                 $user["displayname"]        = $row["displayname"];
                 $user["pin"]                = $row["pin"];
                 
                 $user["statuscode"]           = $row["statuscode"];
         
             array_push($response["logindetails"], $user);
            }
        
            $response["success"] = 1;
            //echo json_encode($response);
           }
           else{
            $response["success"] = 0;
            //echo json_encode($response);
          }
          }else{
            $response["success"] = 0;
            //echo json_encode($response);
          }

          if (!empty($sql_company_result)) {
            // check for empty result
            if (mysqli_num_rows($sql_company_result) > 0) {
          
                while($row = mysqli_fetch_array($sql_company_result)) 
                {
                       $user = array();
                       $user["companycode"]      = $row["companycode"];
                       $user["companyname"]      = $row["companyname"];
                       $user["streetname"]       = $row["streetname"];
                       $user["areaname"]         = $row["areaname"];
                       $user["cityname"]         = $row["cityname"];
                       $user["pincode"]         = $row["pincode"];

                       $user["statuscode"]         = $row["statuscode"];

                   array_push($response["companydetails"], $user);
                  }
              
                  $response["success"] = 1;
                  //echo json_encode($response);
                 }
                 else{
                  $response["success"] = 0;
                  //echo json_encode($response);
                }
                }

     //echo $sql ; die;
     echo json_encode($response);
		   
	}

mysqli_close($con);
?>