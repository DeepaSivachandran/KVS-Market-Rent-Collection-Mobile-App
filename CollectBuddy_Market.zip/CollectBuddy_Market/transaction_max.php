<?php
// include db connect class
require_once __DIR__ . '/db_config.php';
  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");


   $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD,DB_DATABASE) or die(mysqli_error($con));

    mysqli_set_charset($con,"utf8");
  
 
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/
      $deviceid="121";

    $response["receiptcode_details"] = array();
	
	if($deviceid !=""){
     $sql ="SELECT COALESCE(receiptcode,0) as receiptcode, COALESCE(receiptno,0) as receiptno FROM tblcollections ORDER BY autonum DESC LIMIT 1";



     $result = mysqli_stmt_init($con);

     $sql_result = mysqli_query($con,$sql);



     //echo $worker_list; die;
     
      if (!empty($sql_result)) {
      // check for empty result
      if (mysqli_num_rows($sql_result) > 0) {
    
          while($row = mysqli_fetch_array($sql_result)) 
          { 
                 
             $user["receiptcode"]    = $row["receiptcode"];
         
             $user["receiptno"]    = $row["receiptno"];

             array_push($response["receiptcode_details"], $user);
            }
        
            $response["success"] = 1;
            //echo json_encode($response);
           }
           else{
            $response["success"] = 0;
            //echo json_encode($response);
          }
          }else{
            $response["success"] = 0;
            //echo json_encode($response);
          }

     //echo $sql ; die;
     echo json_encode($response);
		   
	}

mysqli_close($con);
?>