<?php

    $id = $_POST['id'];
	$deviceid=$_POST['deviceid'];
    $status=$_POST['status1'];
    $statuscode=$_POST['statuscode'];
	$pass=$_POST['passcode'];
	// $id = 0;
	// $deviceid='588076a64341c856';
	// $status='Active';
	// $statuscode=1;
	// $pass='1234';

			  require_once __DIR__ . '/db_config.php';
			
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
				
			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  
			$params1 = array();
			$params = array();	 
			  $response=array();
			  $report=array();
			 $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
			 $sql2="SELECT * FROM dbo.login WHERE login_pk=$id AND passcode='$pass'";
			 $checkpass = sqlsrv_query($con,$sql2,$params1,$options);
			 
			   if(sqlsrv_num_rows($checkpass)>0){
				   $passcode=$pass;
			   }else{
				   $passcode=hash('sha256', $pass);
			   }
			 
			  $sql1="SELECT count(*) as count FROM dbo.login WHERE deviceid='$deviceid' AND login_pk<>$id";
			  $devicecount = sqlsrv_query($con,$sql1,$params,$options);

			  if(sqlsrv_num_rows($devicecount) > 0)
				{
					while($row = sqlsrv_fetch_array($devicecount,SQLSRV_FETCH_ASSOC)) 
					{
						$count = $row['count'];
					}
				}    
				if ($count != 0)
				{
					$data="Device id already exit";
				}
				else
				{	
					$sql = "UPDATE dbo.login SET deviceid='$deviceid',status='$status',login_status=$statuscode 
					,passcode='$passcode' WHERE login_pk = $id ";	
					$result = sqlsrv_query($con,$sql,$params,$options);
						
					if (!empty($result)) 
					{  
						$data='success';
					}
					else
					{
						 $data='error';
					}
				}
				$report["message"] =$data;
					 
					echo json_encode($report)
            
    
?>