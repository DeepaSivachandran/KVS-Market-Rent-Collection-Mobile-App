<?php

    $id = $_POST['id'];
	$password=$_POST['password'];
	
			  require_once __DIR__ . '/db_config.php';
			
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
				
			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  	 
	               $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
			  
			       $params = array();	 
				   
				    $passcode=hash('sha256', $password);
			 
					$sql = "UPDATE dbo.login SET  passcode= '$passcode' WHERE login_pk = $id ";	
					$result = sqlsrv_query($con,$sql,$params,$options);
						
					if (!empty($result)) 
					{  
						$data='success';
					}
					else
					{
						 $data='error';
					}
				
				$report["message"] =$data;
					 
					echo json_encode($report)
            
    
?>