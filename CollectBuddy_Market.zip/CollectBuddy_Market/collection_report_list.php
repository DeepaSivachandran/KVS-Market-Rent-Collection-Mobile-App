<?php
// include db connect class
require_once __DIR__ . '/db_config.php';
  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");


   $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD,DB_DATABASE) or die(mysqli_error($con));

    mysqli_set_charset($con,"utf8");
  

       if(isset($_POST['paradate'])){
	
        $date = urldecode($_POST['paradate']);
         }
        else{
         $date="";
         }
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/
    //  $deviceid="f22d1103dcce2f11";

    $response["reportdetails"] = array();
    
	
	if($date !=""){
                $sql ="select  COALESCE(receiptno,'') AS receiptno,COALESCE(shopname,'') AS shopname,COALESCE(tenantname,'') AS tenantname,COALESCE(rentcycle,'') AS rentcycle,COALESCE(CAST(totalamount AS DECIMAL(32,2)),0.00) AS totalamount from ( select  d.statusname as rentcycle, a.totalamount, a.receiptno,b.name as shopname,DATE_FORMAT(b.collectiondate, '%d-%m-%Y') as collectiondate,c.tenantname from tblcollections as a
                inner join tblcollection_shop as b on a.collectioncode=b.collectioncode inner join  tbblcollection_tenant as c 
                on a.collectioncode = c.collectioncode inner join tblstatusmaster as d on d.statuscode = b.rentcycle where DATE_FORMAT(b.collectiondate, '%d-%m-%Y')='$date'  order by shopname) derv ORDER BY receiptno";

     $result = mysqli_stmt_init($con);

     $sql_result = mysqli_query($con,$sql);

     //echo $worker_list; die;
     
      if (!empty($sql_result)) {
      // check for empty result
      if (mysqli_num_rows($sql_result) > 0) {
    
          while($row = mysqli_fetch_array($sql_result)) 
          {
                 $user = array();
                 $user["receiptno"]       = $row["receiptno"];
                 $user["shopname"]        = $row["shopname"];
                 $user["tenantname"]      = $row["tenantname"];
                 
                 $user["rentcycle"]      = $row["rentcycle"];
                           
                 $user["totalamount"]      = $row["totalamount"];
        
             array_push($response["reportdetails"], $user);
            }
        
            $response["success"] = 1;
            //echo json_encode($response);
           }
           else{
            $response["success"] = 0;
            //echo json_encode($response);
          }
          }else{
            $response["success"] = 0;
            //echo json_encode($response);
          }


     //echo $sql ; die;
     echo json_encode($response);
		   
	}

mysqli_close($con);
?>