<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <style>
	@import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
*{
	list-style: none;
	text-decoration: none;
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: "Arial, sans-serif";
}
body{
	background: #f5f6fa;
}
.wrapper .sidebar{
	background: rgb(5, 68, 104);
	position: fixed;
	top: 0;
	left: 0;
	width: 225px;
	height: 100%;
	padding: 20px 0;
	transition: all 0.5s ease;
}
.wrapper .sidebar .profile{
	margin-bottom: 30px;
	text-align: center;
}
.wrapper .sidebar ul li a{
	display: block;
	padding: 13px 0px;
	border-bottom: 1px solid #10558d;
	color: rgb(241, 237, 237);
	font-size: 18px;
	position: relative;
}
.wrapper .sidebar ul li a .icon{
	color: #dee4ec;
	width: 30px;
	display: inline-block;
}

.wrapper .section{
	width: calc(100% - 225px);
	margin-left: 225px;
	transition: all 0.5s ease;
}
.wrapper .section .top_navbar{
	background: rgb(5, 68, 104);
	height: 50px;
	display: flex;
	align-items: center;
	padding: 0 30px;
 
}

.wrapper .section .top_navbar .user a{
	font-size: 20px;
	color: #f4fbff;
	margin-left: 5800%;
 
}
.wrapper .section .top_navbar .user a:hover{
	color: #000000;
	display:flex;
}
.wrapper .sidebar .profile h3{
	color: #ffffff;
	margin: 10px 0 5px;
	
}
.wrapper .sidebar ul li a:hover,
.wrapper .sidebar ul li a.active{
	color: #0c7db1;
	background:white;
    border-right: 2px solid rgb(5, 68, 104);
}
.wrapper .sidebar ul li a:hover .icon,
.wrapper .sidebar ul li a.active .icon{
	color: #0c7db1;
	

}
.div-style{
	display: flex;
    align-items: center;
    line-height: 2;
}
.lock-style{
	width: 8%;
	height:35px;
    align-items: center;
    padding: 1.1rem 0.95rem;
    font-size: 1rem;
    font-weight: 400;
    line-height:1.5px;
    color: #212529;
    text-align: center;
    white-space: nowrap;
    background-color: #e9ecef;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
}
.input-style {
	display: block;
    width: 85%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
   
}
.wrapper .sidebar ul li a:hover:before,
.wrapper .sidebar ul li a.active:before{
	display: block;
	
}
.error {
    color: 
red;
   
}

 </style>
 <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
</head>
<body>
    <div class="wrapper" >
     <!--header-->
	  <div class="section">
            <div class="top_navbar">
                
				 <div class="user">
                    <a href="#">
                        <i class="fas fa-user"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="sidebar">
            <div class="profile">
              <h3>KAS Jewellery</h3>
            </div>
             <!--Menu item-->
			 <ul style="margin-left:-17px !important;">
                <li >
                    
					<a href="#list" >
                        <span style="margin-left:30px !important;"  class="icon"><i class="fas fa-user"></i></span>
                        <span  class="item">Agent Master</span>
                    </a>
                </li >
				 <li>
				 <a href="#" >
                    <div  onclick="changepassword_Model()">
                        <span style="margin-left:30px !important;"  class="icon"><i class="fas fa-sign-out-alt"></i></span>
                        <span class="item">Change Password</span>
                    </div>
					  </a>
                </li>
                <li>
                    <a href="Loginpage.php" onclick="return confirm('Are you sure to Logout..?')" >
					
                        <span style="margin-left:30px !important;"  class="icon"><i class="fas fa-sign-out-alt"></i></span>
                        <span class="item">Logout</span>
                    </a>
                </li>
               
			</ul>
       </div> 
	</div>
<div id="list">
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  
 </head>
<body>
    <div class="container-fluid" style="margin-top:20px !important; margin-left:8%;">
        <div class="container">
            <div class="panel panel-default">
                <div  class="panel-heading">
                    <h3 >Agent Master</h3>
					<br>
				
                </div>
            </div>
            <?php
			global $key;
			$code = "";
            $agent= "";
			$deviceid = "";
			
			  require_once __DIR__ . '/db_config.php';
			 
			  $response = array();
			  
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");

			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  
                $sql = "SELECT login_pk,code,agent,deviceid,status FROM dbo.login";
			
                $result = sqlsrv_query($con,$sql);
            ?>
				
		<div class="panel-body">
		<div class="center" style="text-align:right; width:100%; padding:0; margin-bottom:20px">
            <button class="btn btn-primary" type="button" onclick="opensave()" name="signin">Add</button>
            </div>
			<div class="table-responsive">
				<table id="tblUser" class="table table-bordered table-striped">
					<thead>
						<th>S.No</th>				
						<th>Agent Code</th>
						<th>Agent Name</th>
						<th>Device ID</th>
						<th>Status</th>
						<th>Action</th>
					</thead>
					<tbody>
					
						<?php while($user = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) { ?>
							<tr>
								<td><?php echo ++$key; ?></td>
								
								<td><?php echo $user['code']; ?></td>
								<td><?php echo $user['agent']; ?></td>
								<td><?php echo $user['deviceid']; ?></td>
								<td><?php echo $user['status']; ?></td>
								<td>
								<button type="button" class="btn btn-primary btn-sm" 
								onclick=editload(<?php echo $user['login_pk'];?>)>
								<i class="fa fa-pencil-square-o"></i></button> 
								<button type="button" class="btn btn-info btn-sm" 
								onclick=resetpin(<?php echo $user['login_pk'];?>)>
								<i class="fas fa-lock"></i></button>
								</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
				</div>
				</div>
			</div>
    </div>
  <!-- The Modal -->
  
<div class="modal " id="myModal" >
  <div class="modal-dialog">
		<div class="modal-content">

		<!-- Modal Header -->
		<div class="row modal-header m-3">
		<h3 class="modal-title" >Agent Device-ID Update</h3>
			<button type="button" onclick="closeWindow()" style="margin-left:210px; margin-top:-25px; width:100%;" data-dismiss="modal" class="close">&times;</button>
		</div>
			<!-- Modal body -->
			<div class="modal-body">
				
									<form >
										<input type="hidden"  id="txtlogin" >
										<div class="form-group">
										
											<label class="control-label">Agent Code </label>
											<input type="text" class="form-control input-lg" maxlength="60" id="txtagentcode" disabled="disabled">
										</div>
										<div class="form-group mt-2">
											<label class="control-label">Agent Name </label>
											<input type="text" class="form-control input-lg" maxlength="180" id="txtagentname" disabled="disabled">
										</div>
										<div class="form-group">
											<label class="control-label">Device - ID </label>
											<input type="text" class="form-control input-lg" required  autocomplete="off" maxlength="20" id="txtdeviceid" >
										</div>
										<div class="form-group" style="display:none;">
											<label class="control-label">PIN Number</label>
											<input type="password" class="form-control input-lg" required  autocomplete="off"  min="4"  maxlength="4" id="txtpin" >
										</div>
										
									<div class="form-group">
									<label class="control-label">Status </label> 
									
										<fieldset>
									
											<input class="form-check-input" type="radio"  value="Active" name="status1" id="active">
												<label class="form-check-label" for="active">
													Active
												</label>
										
									&nbsp;
									
											<input class="form-check-input" type="radio"  value="Inactive" name="status1" id="inactive" >
												<label class="form-check-label" for="inactive">
													Inactive
												</label>
													
										</fieldset>
									</div>
									</form>
					

						<!-- Modal footer -->
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary mt-2 " onclick=updatetable() id="submit" >Update</button>
							<button type="button" class="btn btn-danger" onclick="closeWindow()" data-dismiss="modal">Close</button>
						</div>

				</div>
		</div>
		</div>
  </div>


  <div class="modal " id="myModalSave" >
  <div class="modal-dialog">
		<div class="modal-content">

		<!-- Modal Header -->
		<div class="row modal-header m-3">
		<h3 class="modal-title" >Save </h3>
			<button type="button" onclick="closeWindow()" style="margin-left:210px; margin-top:-25px; width:100%;" data-dismiss="modal" class="close">&times;</button>
		</div>
			<!-- Modal body -->
			<div class="modal-body">
				
									<form >
										<input type="hidden"  id="txtlogin" >
										<div class="form-group">
										
											<label class="control-label">Agent Code </label>
											<input type="text" class="form-control input-lg" maxlength="60" id="txtagent_code">
										</div>
										<div class="form-group mt-2">
											<label class="control-label">Agent Name </label>
											<input type="text" class="form-control input-lg" maxlength="180" id="txtagent_name" >
										</div>
										<div class="form-group mt-2">
											<label class="control-label">Device - ID </label>
											<input type="text" class="form-control input-lg"  maxlength="20" id="txtdevice_id" >
										</div>
										<div class="form-group mt-2">
											<label class="control-label">PIN Number</label>
											<input type="password" class="form-control input-lg"  min="4"  maxlength="4" id="txtpin_number" >
										</div>
										
									<div class="form-group">
									<label class="control-label">Status </label> 
									
										<fieldset>
									
											<input class="form-check-input" type="radio"  value="Active" name="status_1" id="active_1">
												<label class="form-check-label" for="active">
													Active
												</label>
										
									&nbsp;
									
											<input class="form-check-input" type="radio"  value="Inactive" name="status_1" id="inactive_1" >
												<label class="form-check-label" for="inactive">
													Inactive
												</label>
													
										</fieldset>
									</div>
									</form>
					

						<!-- Modal footer -->
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary mt-2 " onclick=saveload() id="submit" >Save</button>
							<button type="button" class="btn btn-danger" onclick="closeWindow()" data-dismiss="modal">Close</button>
						</div>

				</div>
		</div>
		</div>

  </div>

<div class="modal " id="myModal2" >
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="row modal-header m-3">
      <h3 class="modal-title" >Reset Pin</h3>
		<button type="button" onclick="closeWindow()" style="margin-left:210px; margin-top:-25px; width:100%;" data-dismiss="modal" class="close">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
        
       <form >
	    <input type="hidden"  id="resetpinid" >
		
	
		
		<label for="psw">New Pin</label>
           <div class="div-style">
             <span class="lock-style" id="new"><i class="fas fa-lock"></i></span>
              <input name="password" type="password" class="input-style" onchange="newpasswordchange(event)" maxlength="4" id="pwd" placeholder="Enter New Pin" 
					 required aria-label="password" aria-describedby="basic-addon1" />
                <span class="lock-style" onclick="password_show_hide();">
                  <i class="fas fa-eye" id="show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                </span>
            </div>
					<span class="error" id="newpin_err"> </span>
			<br><br>
		<label for="psw">Confirm Pin</label>
           <div class="div-style">
             <span class="lock-style" id="confirm"><i class="fas fa-lock"></i></span>
              <input name="password" type="password" class="input-style"  maxlength="4" onchange="confirmpasswordchange(event)" id="confirm_pwd" placeholder="Enter Confirm Pin"
					 required aria-label="password" aria-describedby="basic-addon1" />
               <span class="lock-style" onclick="confirm_password_show_hide();">
                  <i class="fas fa-eye" id="confirm_show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="confirm_hide_eye"></i>
               </span>
            </div>
					<span class="error" id="confirm_err"> </span>
        </form>
  

      <!-- Modal footer -->
      <div class="modal-footer">
	    <button type="submit" class="btn btn-primary mt-2 " onclick=savepwd() id="submit" >Save</button>
      </div>

    </div>
  </div>
</div>
</div>


<div class="modal " id="changepwd" >
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="row modal-header m-3">
      <h3 class="modal-title" >Change Password</h3>
		<button type="button" onclick="closePopup()" style="margin-left:210px; margin-top:-25px; width:100%;" data-dismiss="modal" class="close">&times;</button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
        
       <form >
		<label for="psw">Old Password</label>
           <div class="div-style">
             <span class="lock-style" id="oldpass"><i class="fas fa-lock"></i></span>
              <input name="password" type="password" class="input-style" onchange="oldpasswordchange(event)" maxlength="6" id="oldpwd" placeholder="Enter Old Password" 
					 required aria-label="password" aria-describedby="basic-addon1" />
                <span class="lock-style" onclick="old_show_hide();">
                  <i class="fas fa-eye" id="oldpwd_show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="oldpwd_hide_eye"></i>
                </span>
            </div>
					<span class="error" id="oldpwd_err"> </span>
			<br><br>
		<label for="psw">New Password</label>
           <div class="div-style">
             <span class="lock-style" id="newpass"><i class="fas fa-lock"></i></span>
              <input name="password" type="password" class="input-style"  maxlength="6" onchange="newpwdchange(event)" id="new_pwd" placeholder="Enter New Password"
					 required aria-label="password" aria-describedby="basic-addon1" />
               <span class="lock-style" onclick="newpwd_show_hide();">
                  <i class="fas fa-eye" id="newpwd_show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="newpwd_hide_eye"></i>
               </span>
            </div>
					
					<span class="error" id="newpwd_err"> </span>
					
					<br><br>
		<label for="psw">Confirm Password</label>
           <div class="div-style">
             <span class="lock-style" id="confpass"><i class="fas fa-lock"></i></span>
              <input name="password" type="password" class="input-style"  maxlength="6" onchange="confirmpwdchange(event)" id="conf_pwd" placeholder="Enter Confirm Password"
					 required aria-label="password" aria-describedby="basic-addon1" />
               <span class="lock-style" onclick="confpwd_show_hide();">
                  <i class="fas fa-eye" id="confpwd_show_eye"></i>
                  <i class="fas fa-eye-slash d-none" id="confpwd_hide_eye"></i>
               </span>
            </div>
					
					<span class="error" id="confpwd_err"> </span>
        </form>
  

      <!-- Modal footer -->
      <div class="modal-footer">
	    <button type="submit" class="btn btn-primary mt-2 " onclick=Change_pwd() id="submit" >Save</button>
      </div>

    </div>
  </div>
</div>
</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-notify/0.2.0/js/bootstrap-notify.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
	
    jQuery(document).ready(function($) {
		 toastr.options.timeOut = 1500;
        $('#tblUser').DataTable();
        $("#form-body").hide();
		
    } );
	
	
	function newpasswordchange(event){
		if (event.target.value.length === 0 ) {
        $('#newpin_err').html('Please enter new pin');
       } else if(event.target.value.length > 0 && event.target.value.length <4 ) {
		    $('#newpin_err').html('Pin should be minimum 4 characters');
	   }
		else{
			$('#newpin_err').html('');
			
		}
	}
	function confirmpasswordchange(event){
			if (event.target.value.length === 0 ) {
        $('#confirm_err').html('Please enter Confirm pin');
       } else if(event.target.value.length > 0 && event.target.value.length <4 ) {
		    $('#confirm_err').html('Pin should be minimum 4 characters');
	   }
		else{
			$('#confirm_err').html('');
			
		}
	}
	
	function Error_validation(){
	if (!$('#pwd').val()) {
      $('#newpin_err').html('Please enter new pin');
    }
	if ($('#pwd').val().length > 0 && $('#pwd').val().length < 4) {
      $('#newpin_err').html('Pin should be minimum 4 characters');
    }
	if (!$('#confirm_pwd').val()) {
      $('#confirm_err').html('Please enter Confirm pin');
    }
	if ($('#confirm_pwd').val().length > 0 && $('#confirm_pwd').val().length < 4) {
      $('#confirm_err').html('Pin should be minimum 4 characters');
    }
	if($('#pwd').val() != $('#confirm_pwd').val())
	{
			$('#confirm_err').html('Confirm password dose not match');
	}
    if (!($('#pwd').val() === "" || $('#pwd').val() === null) && !($('#pwd').val().length > 0 && $('#pwd').val().length < 4) && 
	!($('#confirm_pwd').val() === "" || $('#confirm_pwd').val() === null) && !($('#confirm_pwd').val().length > 0 && $('#confirm_pwd').val().length < 4) 
	&& !($('#pwd').val() != $('#confirm_pwd').val())) {
      return 1
    } else {
      return 0
    }
	}

	function Save_Error_validation(){
           if($("#txtagent_code").val() === ""){
			$("#txtagent_code").html('Please enter agentcode');
		   }
		   if($("#txtagent_name").val() === ""){
			$("#txtagent_name").html('Please enter agentname');
		   }
	
		if(!$("#txtagent_code").val() === "" && !$("#txtagent_name").val() === ""){
		return 1
		}else{
		return 0
		}
	}


function savepwd(){
	 
	var confirm=$("#confirm_pwd").val();
	var resetpinid=$("#resetpinid").val();
	var error_flag = Error_validation();
		if(error_flag === 1)
		{
			
			 $.ajax({
            url: 'Resetpin.php',
            type: 'POST',
			data : {id:resetpinid,password:confirm},
            success: function(data)
			{
				$json = JSON.parse(data);
				//console.log($json['message']);
				//console.log(data);
				
			   if($json['message']=='success')
			   {
				   $("#myModal2").hide();
					toastr.success("Pin number changed" );	
					$("#tblUser").load(" #tblUser");	
			   }
			   
			   else{
				   
				   $("#myModal2").show();
				   toastr.error("Pin number not changed"); 
				  
			   }
			  	
            }
			
			
        }
		);
			return true;
		}
}

  function password_show_hide()
 {
	var x = document.getElementById("pwd");
	var show_eye = document.getElementById("show_eye");
	var hide_eye = document.getElementById("hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}

 function confirm_password_show_hide()
 {
	var x = document.getElementById("confirm_pwd");
	var show_eye = document.getElementById("confirm_show_eye");
	var hide_eye = document.getElementById("confirm_hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}

  function resetpin (loginid)
  {
	  clearpin();
	  $("#resetpinid").val(loginid);
	  $("#myModal2").show();
  }
  function editload(loginid){
		  clear();
		//console.log(loginid);
		 $.ajax({
            url: 'editload.php',
            type: 'POST',
			data : {id:loginid},
            success: function(data){
             //  console.log(data);
           
			   if(data!=''){
				  
				    $json = JSON.parse(data);
					var loginid=$json['login_pk'];
					var code=$json['code'];
					var agent=$json['agent'];
					var deviceid=$json['deviceid'];
					var status=$json['status'];
					var passcode=$json['passcode'];
				$("#txtlogin").val(loginid);
				$("#txtagentcode").val(code);
				$("#txtagentname").val(agent);
				$("#txtdeviceid").val(deviceid);
				$("#txtpin").val(passcode);
				if (status == 'Active')
						$("#active").prop('checked', true);
					if (status == 'Inactive')
						$("#inactive").prop('checked', true);
					$("#myModal").show();
			   }
			   else{
				   console.log("No data available");
			   }

            }
        });
	}


	function saveload(){

				var agent_code=$("#txtagent_code").val();
				var agent_name=$("#txtagent_name").val();
				var device_id=$("#txtdevice_id").val();
				var pin_number =$("#txtpin_number").val();
				//var status_1=$("#status_1").val();

				var flag = Save_Error_validation();
				//if(flag === 1){

				var status="";
				var login_status=0;
				if($("#active_1").prop("checked")){
					login_status=1;
					status_1='Active';
				}
				if($("#inactive_1").prop("checked")){
					login_status=0;
					status_1='Inactive';
				}
				if(($('#txtagent_code').val() === "" || $('#txtagent_code').val() === null)){
					toastr.error('Please enter agent code'); 
				}
				if(($('#txtagent_name').val() === "" || $('#txtagent_name').val() === null)){
					toastr.error('Please enter agent name'); 
				}

				if(($('#txtagent_code').val() === "" || $('#txtagent_code').val() === null)){
					toastr.error('Enter valid pin'); 
				}
			
				if(!($('#txtagent_code').val() === "" || $('#txtagent_code').val() === null) && !($('#txtagent_name').val() === "" || $('#txtagent_name').val() === null)){

							if(!($('#txtpin_number').val() === "" || $('#txtpin_number').val() === null) && !($('#txtpin_number').val().length > 0 && $('#txtpin_number').val().length < 4)){
							//console.log(loginid);
							$.ajax({
								url: 'inserttable.php',
								type: 'POST',
								data : {agentname:agent_name,agentcode:agent_code,deviceid:device_id,status:status_1,login_status:login_status,pin_number:pin_number},
								success: function(data){
								console.log(data);
							
								if(data!=''){
									
									/* $json = JSON.parse(data);
										var loginid=$json['login_pk'];
										var code=$json['code'];
										var agent=$json['agent'];
										var deviceid=$json['deviceid'];
										var status=$json['status'];
										var passcode=$json['passcode'];
									$("#txtlogin").val(loginid);
									$("#txtagentcode").val(code);
									$("#txtagentname").val(agent);
									$("#txtdeviceid").val(deviceid);
									$("#txtpin").val(passcode);
									if (status == 'Active')
											$("#active").prop('checked', true);
										if (status == 'Inactive')
											$("#inactive").prop('checked', true);*/

									$json = JSON.parse(data);
								
									if($json['success'] ==1){
									toastr.success($json['message']);
									$("#tblUser").load(" #tblUser");	 
									closeWindow()
									}
									if($json['success'] ==0){
									toastr.error('Error While Saving'); 
									}
							
								}
								else{
									console.log("No data available");
								}

								}
							});
						//}
				}
							
		}
	}

	function opensave(){
		$("#txtagent_code").val("");
		$("#txtagent_name").val("");
		$("#txtdevice_id").val("");
		
		$("#txtpin_number").val("");
		$("#myModalSave").show();
	}
	function clear()
	{
			$("#txtlogin").val("");
			$("#txtagentcode").val("");
			$("#txtagentname").val("");
			$("#txtdeviceid").val("");
			$("#txtpin").val("");
	}
	function clearpin()
	{
			$("#pwd").val("");
			$("#confirm_pwd").val("");
			$('#newpin_err').html('');
			$('#confirm_err').html('');
	}
	function closeWindow() 
	{
	$("#myModal").hide();
	$("#myModal2").hide();
	$("#myModalSave").hide();
	}
 
function updatetable(){
		  
		var loginid=$("#txtlogin").val();
		var deviceid=$("#txtdeviceid").val();
		var passcode=$("#txtpin").val();
	
		var status="";
		var login_status=0;
		if($("#active").prop("checked")){
			login_status=1;
			status='Active';
		}
		if($("#inactive").prop("checked")){
			login_status=0;
			status='Inactive';
		}
	
		 $.ajax({
            url: 'updatetable.php',

            type: 'POST',
			data : {id:loginid,deviceid:deviceid,status1:status,statuscode:login_status,passcode:passcode},
            success: function(data)
			{
				$json = JSON.parse(data);
				
			   if($json['message']=='success')
			   {
				   $("#myModal").hide();
					toastr.success("Updated successfully" );	
					$("#tblUser").load(" #tblUser");	
			   }
			   
			   else{
				   $("#myModal").show();
				   toastr.error($json['message']); 
			   }
			  	
            }
			
			
        }
		);
		
	}	

 function changepassword_Model()
 {
	  clearpwd();
	$("#changepwd").show();	
}
  function closePopup() 
{
   $("#changepwd").hide();
  }

function old_show_hide()
 {
	var x = document.getElementById("oldpwd");
	var show_eye = document.getElementById("oldpwd_show_eye");
	var hide_eye = document.getElementById("oldpwd_hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}
function newpwd_show_hide()
 {
	var x = document.getElementById("new_pwd");
	var show_eye = document.getElementById("newpwd_show_eye");
	var hide_eye = document.getElementById("newpwd_hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}

 function confpwd_show_hide()
 {
	var x = document.getElementById("conf_pwd");
	var show_eye = document.getElementById("confpwd_show_eye");
	var hide_eye = document.getElementById("confpwd_hide_eye");
	hide_eye.classList.remove("d-none");
  if (x.type === "password") 
  {
    x.type = "text";
	show_eye.style.display = "none";
    hide_eye.style.display = "block";
  } 
  else 
  {
    x.type = "password";
	 show_eye.style.display = "block";
    hide_eye.style.display = "none";
  }
}


function oldpasswordchange(event){
		if (event.target.value.length === 0 ) {
        $('#oldpwd_err').html('Please enter Old password');
       } else if(event.target.value.length > 0 && event.target.value.length <4 ) {
		    $('#oldpwd_err').html('Password should be minimum 4 characters');
	   }
		else{
			$('#oldpwd_err').html('');
			
		}
	}

	function newpwdchange(event){
		if (event.target.value.length === 0 ) {
        $('#newpwd_err').html('Please enter new password');
       } else if(event.target.value.length > 0 && event.target.value.length <4 ) {
		    $('#newpwd_err').html('Password should be minimum 4 characters');
	   }
		else{
			$('#newpwd_err').html('');
			
		}
	}
	function confirmpwdchange(event){
			if (event.target.value.length === 0 ) {
        $('#confpwd_err').html('Please enter Confirm password');
       } else if(event.target.value.length > 0 && event.target.value.length <4 ) {
		    $('#confpwd_err').html('Password should be minimum 4 characters');
	   }
		else{
			$('#confpwd_err').html('');
			
		}
	}
	
	function pwd_validation(){
		
				if (!$('#oldpwd').val()) {
				$('#oldpwd_err').html('Please enter old password');
				}
				if ($('#oldpwd').val().length > 0 && $('#oldpwd').val().length < 4) {
				$('#oldpwd_err').html('Password should be minimum 4 characters');
				}
				
				if (!$('#new_pwd').val()) {
				$('#newpwd_err').html('Please enter new password');
				}
				if ($('#new_pwd').val().length > 0 && $('#new_pwd').val().length < 4) {
				$('#newpwd_err').html('Password should be minimum 4 characters');
				}
				
				if (!$('#conf_pwd').val()) {
				$('#confpwd_err').html('Please enter Confirm password');
				}
				if ($('#conf_pwd').val().length > 0 && $('#conf_pwd').val().length < 4) {
				$('#confpwd_err').html('Password should be minimum 4 characters');
				}
				
				if($('#new_pwd').val() != $('#conf_pwd').val())
				{
						$('#confpwd_err').html('Confirm password dose not match');
				}
				if ( !($('#oldpwd').val() === "" || $('#oldpwd').val() === null) && !($('#oldpwd').val().length > 0 && $('#oldpwd').val().length < 4) && !($('#new_pwd').val() === "" || $('#new_pwd').val() === null) && !($('#new_pwd').val().length > 0 && $('#new_pwd').val().length < 4) && !($('#conf_pwd').val() === "" || $('#conf_pwd').val() === null) && !($('#conf_pwd').val().length > 0 && $('#conf_pwd').val().length < 4) && !($('#new_pwd').val() != $('#conf_pwd').val())) {
				return 1
				} else {
				return 0
				}
	}
function clearpwd()
{
		$("#oldpwd").val("");
		$("#new_pwd").val("");
		$("#conf_pwd").val("");
		$('#oldpwd_err').html('');
		$('#newpwd_err').html('');
		$('#confpwd_err').html('');
		
}
 function Change_pwd(){
	var conf_pwd=$("#conf_pwd").val();
	var oldpassword=$("#oldpwd").val();
	var error_flag = pwd_validation();
		if(error_flag === 1)
		{
			
			 $.ajax({
            url: 'Changepwd.php',
            type: 'POST',
			data : {old_pwd:oldpassword,new_pwd:conf_pwd},
			
            success: function(data)
			{
				$json = JSON.parse(data);
			   if($json['message']=='success')
			   {
				   $("#changepwd").hide();
					toastr.success("Password  changed" );
					setTimeout(() => {
						top.location.href="Loginpage.php";
					}, 1000);	
			   }
			   else{
				   $("#changepwd").show();
				   toastr.error($json['message']); 
			   }
			  	
            }
			
			
        }
		);
			return true;
		}
	
}
    </script>

</body>
</html>
</div>

	</body>
	</html>