
<?php
// include db connect class
require_once __DIR__ . '/db_config.php';
  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");


   $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD,DB_DATABASE) or die(mysqli_error($con));

    mysqli_set_charset($con,"utf8");
  
    if(isset($_POST['pararequest'])){
		
       $request = urldecode($_POST['pararequest']);
	   }
	  else{
	   $request="";
	   }
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/

      $response["daily_collection_details"] = array();
   
	
            //REQUEST  1 is used to get daily collection details
            if($request == 1){

                    // $sql ="SELECT (@row_number:=@row_number + 1) AS num,a.*,b.*,c.* FROM tbltenantmaster as a 
                    //                     inner join tbltenantmaster_details as b 
                    //                     on b.tenantcode = a.tenantcode 
                    //                     left join tblshopmaster as c on b.shopcode = c.shopcode,(SELECT @row_number:=0) AS t WHERE c.rentcycle =6";

                    $sql = "select derv.*,derv2.statuscode,derv2.statusname,derv.shopstatus,derv.rentcycle from (
                        select a.tenantcode, a.tenantname, b.shopcode,c.shopstatus,c.rentcycle, c.name as shopname,c.rent from tbltenantmaster as a
                        inner join tbltenantmaster_details as b on a.tenantcode = b.tenantcode inner join tblshopmaster 
                        as c on c.shopcode = b.shopcode where c.statuscode = 1 and c.shopstatus = 3 and c.rentcycle = 6)derv 
                        left join(
                        select b.shopcode,a.statuscode,c.statusname from tblcollections as a inner join tblcollection_shop as b on a.collectioncode = b.collectioncode
                        and DATE_FORMAT(b.collectiondate, '%d-%m-%Y') = DATE_FORMAT( ADDTIME(now(), (SELECT timediff FROM tblsettings)), '%d-%m-%Y')
                        inner join tblstatusmaster as c on a.statuscode=c.statuscode )derv2
                        on derv.shopcode=derv2.shopcode order by cast(shopname as unsigned)";

                    $result = mysqli_stmt_init($con);

                    $sql_result = mysqli_query($con,$sql);


                    //echo $worker_list; die;
                    
                    if (!empty($sql_result)) {
                    // check for empty result
                    if (mysqli_num_rows($sql_result) > 0) {
                    
                        while($row = mysqli_fetch_array($sql_result)) 
                        {
                                $user = array();
                                $user["tenantcode"]     = $row["tenantcode"];
                                $user["tenantname"]     = $row["tenantname"];
                                $user["rent"]            = $row["rent"];
                                $user["shopcode"]       = $row["shopcode"];
                                $user["shopname"]       = $row["shopname"];

                                $user["olddue_amount"]   = "";
                                $user["due_amount"]      = $row["rent"];
                                $user["total_amount"]    = $row["rent"];

                                $user["statuscode"]       = $row["statuscode"];
                                $user["statusname"]       = $row["statusname"];

                                
                                $user["shopstatus"]       = $row["shopstatus"];
                                $user["rentcycle"]       = $row["rentcycle"];
                                
                            array_push($response["daily_collection_details"], $user);
                            }
                        
                            $response["success"] = 1;
                            //echo json_encode($response);
                        }
                        else{
                            $response["success"] = 0;
                            //echo json_encode($response);
                        }
                        }else{
                            $response["success"] = 0;
                            //echo json_encode($response);
                        }

                    }

                      //REQUEST  1 is used to get monthly collection details
                    if($request == 2){
                        
                    //   $sql ="SELECT (@row_number:=@row_number + 1) AS num,a.*,b.*,c.* FROM tbltenantmaster as a 
                    //                       inner join tbltenantmaster_details as b 
                    //                       on b.tenantcode = a.tenantcode 
                    //                       left join tblshopmaster as c on b.shopcode = c.shopcode,(SELECT @row_number:=0) AS t WHERE c.rentcycle =5";

                      $sql = "select derv.*,derv2.statuscode,derv2.statusname,derv.shopstatus,derv.rentcycle from (
                        select a.tenantcode, a.tenantname, b.shopcode,c.shopstatus,c.rentcycle, c.name as shopname,c.rent from tbltenantmaster as a
                        inner join tbltenantmaster_details as b on a.tenantcode = b.tenantcode inner join tblshopmaster 
                        as c on c.shopcode = b.shopcode where c.statuscode = 1 and c.shopstatus = 3 and c.rentcycle = 5)derv 
                        left join(
                        select b.shopcode,a.statuscode,c.statusname from tblcollections as a inner join tblcollection_shop as b on a.collectioncode = b.collectioncode
                        and DATE_FORMAT(b.collectiondate, '%d-%m-%Y') = DATE_FORMAT(ADDTIME(now(), (SELECT timediff FROM tblsettings)), '%d-%m-%Y')
                        inner join tblstatusmaster as c on a.statuscode=c.statuscode )derv2
                        on derv.shopcode=derv2.shopcode order by cast(shopname as unsigned)";

           

                                        
                                        $result = mysqli_stmt_init($con);

                                        $sql_result = mysqli_query($con,$sql);


                                        //echo $worker_list; die;
                                        
                                        if (!empty($sql_result)) {
                                        // check for empty result
                                        if (mysqli_num_rows($sql_result) > 0) {
                                        
                                            while($row = mysqli_fetch_array($sql_result)) 
                                            {
                                                    $user = array();
                                                    $user["tenantcode"]     = $row["tenantcode"];
                                                    $user["tenantname"]     = $row["tenantname"];
                                                    $user["rent"]           = $row["rent"];
                                                    $user["shopcode"]       = $row["shopcode"];
                                                    $user["shopname"]       = $row["shopname"];

                                                    $user["olddue_amount"]   = "";
                                                    $user["due_amount"]      = $row["rent"];
                                                    $user["total_amount"]    = $row["rent"];

                                                    $user["statuscode"]       = $row["statuscode"];
                                                    $user["statusname"]       = $row["statusname"];
                                                    
                                                    $user["shopstatus"]       = $row["shopstatus"];
                                                    $user["rentcycle"]       = $row["rentcycle"];
                                                    
                                                array_push($response["daily_collection_details"], $user);
                                                }
                                            
                                                $response["success"] = 1;
                                                //echo json_encode($response);
                                            }
                                            else{
                                                $response["success"] = 0;
                                                //echo json_encode($response);
                                            }
                                            }else{
                                                $response["success"] = 0;
                                                //echo json_encode($response);
                                            }
                        }

     //echo $sql ; die;
     echo json_encode($response);
		   


mysqli_close($con);
?>