<?php

    /*$id = $_POST['id'];
	$deviceid=$_POST['deviceid'];
    $status=$_POST['status1'];
    $statuscode=$_POST['statuscode'];
	$pass=$_POST['passcode'];*/
	/* $id = 0;
	 $deviceid='588076a64341c856';
	 $status='Active';
	 $statuscode=1;
	 $pass='1234';*/

     $agent_name=$_POST['agentname'];
     $agent_code=$_POST['agentcode'];
     $device_id=$_POST['deviceid'];
     $status = $_POST['status'];
     $login_status = $_POST['login_status'];
	 $pin_number = $_POST['pin_number'];
	
     $count =0;

			  require_once __DIR__ . '/db_config.php';
			
			  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");
				
			  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
			  
			  $params1 = array();
			  $params = array();	 
			  $response=array();
			  $report=array();
			  $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
			/* $sql2="SELECT * FROM dbo.login WHERE login_pk=$id AND passcode='$pass'";
			 $checkpass = sqlsrv_query($con,$sql2,$params1,$options);
			 
			   if(sqlsrv_num_rows($checkpass)>0){
				   $passcode=$pass;
			   }else{
				   $passcode=hash('sha256', $pass);
			   }*/
			 
			  /*$sql1="SELECT count(*) as count FROM dbo.login WHERE deviceid='$deviceid' AND login_pk<>$id";
			  $devicecount = sqlsrv_query($con,$sql1,$params,$options);

			  if(sqlsrv_num_rows($devicecount) > 0)
				{
					while($row = sqlsrv_fetch_array($devicecount,SQLSRV_FETCH_ASSOC)) 
					{
						$count = $row['count'];
					}
				}*/    
				/*if ($count != 0)
				{
					$data="Device id already exit";
				}
				else
				{*/	
					$passcode = hash('sha256', $pin_number);

					$sql = "INSERT INTO login(login_pk,code,agent,deviceid,login_status,status,passcode) SELECT COALESCE(max(login_pk)+1,null) as login_pk,'$agent_code' as code,'$agent_name' as agent , '$device_id' as device_id,'$login_status' as login_status,'$status' as status, '$passcode' as passcode FROM login";	
					
					//echo $sql; die;
	
					$result = sqlsrv_query($con,$sql,$params,$options);
				
					//$rows_affected = sqlsrv_rows_affected($result);
					if ($result) 
					{  
						$data='Saved Successfully';	
						$success =1;
					}else
					{ 
						$data='Error While Saving';
						$success =0;
					}
				//}
				$report["message"] =$data;
				$report["success"] =$success;	 
				echo json_encode($report)
    
    
?>