<?php
// include db connect class

require_once __DIR__ . '/db_config.php';
//To Write error log
 ///require_once __DIR__ . '/catchexception.php'; 


  // connecting to db
  $response = array();
  
  $conninfro = array("Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD, "CharacterSet" =>"UTF-8");

  $con = sqlsrv_connect(DB_SERVER,$conninfro) or die(sqlsrv_errors($con));
  //mysqli_set_charset($con,"utf8");
  
    if(isset($_POST['paracode'])){
		
      $agent_code = urldecode($_POST['paracode']);
	  }
	  else{
	    $agent_code="";
   	}

   // echo  date('Y-m-d', time());

   // echo date('d-m-Y', strtotime(date('d-m-Y')." -3 month"));
   // $str = date('d-m-Y', strtotime(date('d-m-Y')." -1 month"));
    //echo date('d-m-Y', strtotime($str." -1 year"));
    //date('m',strtotime("-3 month"));

  /* $start_date="13-10-2022";
   $end_date="01-07-2022";
   $end_year="01-01-2021";*/


   $start_date = date('Y-m', time());
   $end_date   = date('Y-m', strtotime(date('Y-m-d', time())." -3 month"));
   $end_year   = date('Y-m', strtotime(date('Y-m-d', strtotime(date('Y-m-d', time())." -3 month"))." -1 year"));
   // $password = hash('sha256', $_POST['parapasscode']);
  

      /*$empid="VMK";
      $deviceid="eba7eac7c658ca44";
      $password=hash('sha256', 1234);//md5(1234);
      $count ="3";*/
 
       $ipaddress = "";
       //$deviceid="f22d1103dcce2f11";
       //echo $password;


       $response["citydetails"] = array();
       $response["masterdetails"] = array();
  
    	
	if($agent_code !=""){
    $params = array();	 
    $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );


     // $sql_city="SELECT  DISTINCT(city_name)  FROM master  WHERE ag_code='$agent_code' ORDER BY city_name ASC";

      $sql_city = "SELECT coalesce(city_name,'null') as city_name ,COUNT(*) as total_customer FROM master  WHERE ag_code='$agent_code' GROUP BY city_name ORDER BY city_name ASC";
		  $result_city = sqlsrv_query($con,$sql_city,$params,$options);

       if (!empty($result_city)) {
           // check for empty result
              if (sqlsrv_num_rows($result_city) > 0) {
     
                  while($row = sqlsrv_fetch_array($result_city,SQLSRV_FETCH_ASSOC)) 
                  {
                   $user = array();
                   $user["cityname"] = $row["city_name"];
                   $user["totalcustomer"] = $row["total_customer"];
                   
                   array_push($response["citydetails"], $user);
                  }
                
         
               }
        }

        //OLD
// $sql = "select v.*,(CASE WHEN v.active_status =0 and v.pending_status=0 THEN '1' ELSE '0' END) as inactive_status from
// (select t1.* ,
// (SELECT (CASE WHEN COUNT(receiptno)>0 THEN '1' ELSE '0' END) as a_count FROM transact as an where FORMAT(CONVERT(date,an.collectdt),'MM-yyyy') >= '$end_date' AND FORMAT(CONVERT(date,an.collectdt),'MM-yyyy') <= '$start_date' AND an.ag_code='$agent_code' and  an.acno=t1.accountno) as active_status, 
  
//   (SELECT (CASE WHEN COUNT(receiptno)>0 THEN '1' ELSE '0' END) as p_count FROM transact as pn where FORMAT(CONVERT(date,pn.collectdt),'MM-yyyy') >= '$end_year' AND FORMAT(CONVERT(date,pn.collectdt),'MM-yyyy') <= '$end_date' AND pn.ag_code='$agent_code' and  pn.acno=t1.accountno) as pending_status FROM master as t1) as v where v.ag_code='$agent_code'";

//NEW
  $sql  = "SELECT a.*,(CASE WHEN a.active_status =0 and a.pending_status=0 THEN '1' ELSE '0' END) as inactive_status FROM 
  (SELECT v.*,(CASE WHEN FORMAT(CONVERT(date,v.lasttransdt),'yyyy-MM') >= '$end_date' AND FORMAT(CONVERT(date,v.lasttransdt),'yyyy-MM') <= '$start_date' THEN '1' ELSE '0' END ) as active_status,
  (CASE WHEN FORMAT(CONVERT(date,v.lasttransdt),'yyyy-MM') >= '$end_year' AND FORMAT(CONVERT(date,v.lasttransdt),'yyyy-MM') <= '$end_date' THEN '1' ELSE '0' END ) as pending_status FROM master as v) as a WHERE a.ag_code = '$agent_code'";
 // echo $sql; die;
// echo $start_date."\n";
// echo $end_date."\n";
// echo $end_year."\n";
// echo $sql; die;
  
     $result = sqlsrv_query($con,$sql,$params,$options);

	      if (!empty($result)) {
         // check for empty result
           if (sqlsrv_num_rows($result) > 0) {
      
               while($row = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) 
                {
				          $user = array();
				  
                  $user["accountno"] = $row["accountno"];
                  $user["name"] =  $row["name"];
                  $user["Phone_no"] =  $row["Phone_no"];
                  $user["address1"] =  $row["address1"];
                  $user["address2"] =  $row["address2"];
                  
                  $user["lasttransdt"] =  $row["lasttransdt"];
                  $user["actype"] =  $row["actype"];
                  $user["amount"] =  $row["amount"];
                  $user["multiplicationamt"] =  $row["multiplicationamt"];
                  $user["limitamt"] =  $row["limitamt"];
                  $user["insamt"] =  $row["insamt"];
                  $user["duedt"] =  $row["duedt"];
                  $user["ag_code"] =  $row["ag_code"];
                  $user["ag_name"] =  $row["ag_name"];
                  $user["optcl"] =  $row["optcl"];
                  $user["minamt"] =  $row["minamt"];
                  $user["multiamtlimit"] =  $row["multiamtlimit"];
                  $user["period"] =  $row["period"];
                  $user["interestamt"] =  $row["interestamt"];
                  $user["totalamt"] =  $row["totalamt"];
                  $user["penaltyamt"] =  $row["penaltyamt"];
                  $user["interestpaid"] =  $row["interestpaid"];
                  $user["interestdue"] =  $row["interestdue"];
                  $user["loanbaldue"] =  $row["loanbaldue"];
                  $user["rate"] =  $row["rate"];
                  $user["pendingpenalty"] =  $row["pendingpenalty"];
                  $user["colinterest"] =  $row["colinterest"];
                  $user["Totinsttno"] =  $row["Totinsttno"];
                  $user["Paidinstno"] =  $row["Paidinstno"];
                  $user["EnableInst"] =  $row["EnableInst"];
                  $user["Doorno"] =  $row["Doorno"];
                  $user["StreetName"] =  $row["StreetName"];
                  $user["DownlaodFlag"] =  $row["DownlaodFlag"];
                  $user["CreatedOn"] =  $row["CreatedOn"];
                  $user["Remark"] =  $row["Remark"];
                  $user["EmiNumber"] =  $row["EmiNumber"];
                  $user["CollectionTypeID"] =  $row["CollectionTypeID"];
                  $user["branch_id"] =  $row["branch_id"];
                  $user["Branch_code"] =  $row["Branch_code"];
                  $user["DDCode"] =  $row["DDCode"];
                  $user["InstPending"] =  $row["InstPending"];
                  $user["FineAmount"] =  $row["FineAmount"];
                  $user["DailyAmount"] =  $row["DailyAmount"];
                  $user["NoticeAmount"] =  $row["NoticeAmount"];
                  $user["AmountinSus"] =  $row["AmountinSus"];
                  $user["IsLoan"] =  $row["IsLoan"];
                  $user["cityname"] =  $row["city_name"];

                  $user["balance_amount"] =  $row["Balance_amount"];

                  $user["maturity_amount"] =  $row["Maturity_amount"];
                  
                  $user["active_status"] =  $row["active_status"];
                  $user["pending_status"] =  $row["pending_status"];
                  $user["inactive_status"] =  $row["inactive_status"];
                  
                  $user["BILLNO"] =  $row["BILLNO"];
                  $user["BILLDATE"] =  $row["BILLDATE"];

                 // $user["deviceid"] = $row["deviceid"];
                 
                  array_push($response["masterdetails"], $user);
				
			    }
			}
                  $response["success"] = 1;
				         $response["error"] = "";
                  echo json_encode($response);
		}
	   else{
			     $err= sqlsrv_errors(); 
			      $response["error"] = $err;
                  echo json_encode($response);
		   }
		   
	 sqlsrv_free_stmt($result);
		   
	}

sqlsrv_close($con);

?>